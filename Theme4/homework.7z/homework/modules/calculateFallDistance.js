export function calculateFallDistance(t) {
  return 1/2 * 9.8 * t * t;
}