export function celsiusToFahrenheit(c) {
  return 9 / 5 * c  + 32; 
}