export function concatStrings(s1, s2) {
  console.log("first word = ", s1, "second word = ", s2);
}