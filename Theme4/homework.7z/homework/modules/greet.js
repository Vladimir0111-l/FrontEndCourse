import {myName} from "../script.js"
export function greet() {
  console.log("Hello",myName)
}